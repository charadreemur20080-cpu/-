SiftiteUpgrade
==============
/siftite upgrade  - opens the upgrade menu. Pick a netherite tool, weapon or armor piece
                    and pay $50,000 (change it in config.yml) to turn it into Siftite.

Look (textures): upload SiftitePack.zip somewhere that gives a DIRECT download link,
paste the link into plugins/SiftiteUpgrade/config.yml under resource-pack.url, and
restart. Players get the pack when they join (or type /siftite pack).
Without the pack the items still work, they just look like netherite.
