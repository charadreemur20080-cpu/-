package dev.siftiteupgrade;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SiftiteUpgrade extends JavaPlugin implements Listener, CommandExecutor {

    private static final String[] KINDS = {
            "SWORD", "AXE", "PICKAXE", "SHOVEL", "HOE", "HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS"
    };
    private static final int CONFIRM_SLOT = 40;
    private static final int SELECTED_SLOT = 38;
    private static final int RESULT_SLOT = 42;
    private static final int BALANCE_SLOT = 45;
    private static final int CLOSE_SLOT = 49;
    private static final int GRID_SIZE = 36;

    private Economy economy;
    private NamespacedKey siftiteKey;
    private double cost;
    private double mult;

    private static class UpgradeHolder implements InventoryHolder {
        int selected = -1;                       // player inventory index of the chosen item
        final List<Integer> slots = new ArrayList<>(); // inventory indexes shown in the grid

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    // ------------------------------------------------------------------
    @Override
    public void onEnable() {
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            getLogger().severe("No Vault economy found! Install Vault and an economy plugin (e.g. EssentialsX).");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        economy = rsp.getProvider();
        saveDefaultConfig();
        cost = getConfig().getDouble("cost", 50000);
        mult = getConfig().getDouble("stat-multiplier", 1.1);
        siftiteKey = new NamespacedKey(this, "siftite");
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("siftite").setExecutor(this);
    }

    // ------------------------------------------------------------------
    // Resource pack
    // ------------------------------------------------------------------
    private boolean sendPack(Player p) {
        String url = getConfig().getString("resource-pack.url", "");
        if (url == null || url.isBlank()) return false;
        String sha = getConfig().getString("resource-pack.sha1", "");
        boolean force = getConfig().getBoolean("resource-pack.required", false);
        Component prompt = Component.text(getConfig().getString("resource-pack.prompt", "Siftite gear textures"));
        try {
            byte[] hash = null;
            if (sha != null && sha.length() == 40) {
                hash = new byte[20];
                for (int i = 0; i < 20; i++) hash[i] = (byte) Integer.parseInt(sha.substring(2 * i, 2 * i + 2), 16);
            }
            p.setResourcePack(url, hash, prompt, force);
            return true;
        } catch (Exception ex) {
            getLogger().warning("Could not send the resource pack: " + ex);
            return false;
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(this, () -> sendPack(e.getPlayer()), 40L);
    }

    // ------------------------------------------------------------------
    // Command
    // ------------------------------------------------------------------
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Only players can use /siftite.");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("upgrade")) {
            UpgradeHolder holder = new UpgradeHolder();
            Inventory inv = Bukkit.createInventory(holder, 54, "\u00a78Siftite Upgrade");
            render(p, holder, inv);
            p.openInventory(inv);
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("pack")) {
            if (!sendPack(p)) p.sendMessage("\u00a7cNo resource pack is set up on this server.");
            return true;
        }
        p.sendMessage("\u00a7eUsage: \u00a7f/siftite upgrade \u00a77- turn netherite gear into Siftite");
        return true;
    }

    // ------------------------------------------------------------------
    // Item helpers
    // ------------------------------------------------------------------
    private static String kindOf(Material m) {
        String n = m.name();
        if (!n.startsWith("NETHERITE_")) return null;
        String k = n.substring("NETHERITE_".length());
        for (String s : KINDS) if (s.equals(k)) return s.toLowerCase(Locale.ROOT);
        return null;
    }

    private boolean isSiftite(ItemStack it) {
        return it.hasItemMeta() && it.getItemMeta().getPersistentDataContainer()
                .has(siftiteKey, PersistentDataType.BYTE);
    }

    private boolean eligible(ItemStack it) {
        return it != null && it.getType() != Material.AIR && kindOf(it.getType()) != null && !isSiftite(it);
    }

    private static String pretty(String s) {
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private ItemStack makeSiftite(ItemStack src) {
        Material m = src.getType();
        String kind = kindOf(m);
        ItemStack out = src.clone();
        ItemMeta meta = out.getItemMeta();

        meta.getPersistentDataContainer().set(siftiteKey, PersistentDataType.BYTE, (byte) 1);
        meta.setItemModel(new NamespacedKey("siftite", "siftite_" + kind));

        if (!meta.hasDisplayName()) {
            meta.displayName(Component.text("Siftite " + pretty(kind))
                    .color(NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false));
        }
        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        long pct = Math.round((mult - 1.0) * 100);
        lore.add("");
        lore.add("\u00a77Upgraded from Netherite");
        lore.add("\u00a7f+" + pct + "% stronger than Netherite");
        meta.setLore(lore);

        EquipmentSlot slot = switch (kind) {
            case "helmet" -> EquipmentSlot.HEAD;
            case "chestplate" -> EquipmentSlot.CHEST;
            case "leggings" -> EquipmentSlot.LEGS;
            case "boots" -> EquipmentSlot.FEET;
            default -> EquipmentSlot.HAND;
        };
        boolean armor = slot != EquipmentSlot.HAND;
        boolean digTool = kind.equals("pickaxe") || kind.equals("axe") || kind.equals("shovel") || kind.equals("hoe");

        // Attributes: scale netherite's values
        Multimap<Attribute, AttributeModifier> base = meta.hasAttributeModifiers()
                ? meta.getAttributeModifiers()
                : m.getDefaultAttributeModifiers(slot);
        Multimap<Attribute, AttributeModifier> scaled = ArrayListMultimap.create();
        for (Map.Entry<Attribute, AttributeModifier> e : base.entries()) {
            Attribute a = e.getKey();
            AttributeModifier mod = e.getValue();
            double amount = mod.getAmount();
            if (a == Attribute.ATTACK_DAMAGE && mod.getOperation() == AttributeModifier.Operation.ADD_NUMBER) {
                amount = (amount + 1.0) * mult - 1.0; // the +1 is the player's base damage
            } else if (a == Attribute.ARMOR || a == Attribute.ARMOR_TOUGHNESS || a == Attribute.KNOCKBACK_RESISTANCE) {
                amount = amount * mult;
            }
            NamespacedKey key = new NamespacedKey(this, "siftite_" + a.getKey().getKey() + "_" + kind);
            scaled.put(a, new AttributeModifier(key, amount, mod.getOperation(), mod.getSlotGroup()));
        }
        if (digTool) {
            // Netherite mines at speed 9, so +9 * (multiplier - 1) makes it multiplier times as fast
            scaled.put(Attribute.MINING_EFFICIENCY, new AttributeModifier(
                    new NamespacedKey(this, "siftite_mining_" + kind),
                    9.0 * (mult - 1.0), AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        }
        meta.setAttributeModifiers(scaled);

        // Durability
        if (meta instanceof Damageable d) {
            d.setMaxDamage((int) Math.round(m.getMaxDurability() * mult));
        }

        // Worn look for armor
        if (armor) {
            EquippableComponent eq = meta.getEquippable();
            eq.setSlot(slot);
            eq.setModel(new NamespacedKey("siftite", "siftite"));
            eq.setEquipSound(Sound.ITEM_ARMOR_EQUIP_NETHERITE);
            meta.setEquippable(eq);
        }

        out.setItemMeta(meta);
        return out;
    }

    // ------------------------------------------------------------------
    // GUI
    // ------------------------------------------------------------------
    private ItemStack plain(Material mat, String name, String... lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        if (lore.length > 0) meta.setLore(Arrays.asList(lore));
        meta.addItemFlags(ItemFlag.values());
        it.setItemMeta(meta);
        return it;
    }

    private static String money(double v) {
        return String.format(Locale.US, "%,.0f", v);
    }

    private ItemStack withExtraLore(ItemStack src, boolean selected, String... extra) {
        ItemStack it = src.clone();
        ItemMeta meta = it.getItemMeta();
        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        lore.add("");
        lore.addAll(Arrays.asList(extra));
        meta.setLore(lore);
        if (selected) meta.setEnchantmentGlintOverride(true);
        it.setItemMeta(meta);
        return it;
    }

    private void render(Player p, UpgradeHolder h, Inventory inv) {
        ItemStack filler = plain(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);

        // Collect netherite gear the player is carrying or wearing
        h.slots.clear();
        PlayerInventory pi = p.getInventory();
        for (int i = 0; i < 40 && h.slots.size() < GRID_SIZE; i++) {
            if (eligible(pi.getItem(i))) h.slots.add(i);
        }
        if (!h.slots.contains(h.selected)) h.selected = -1;

        for (int g = 0; g < h.slots.size(); g++) {
            int invIndex = h.slots.get(g);
            boolean sel = invIndex == h.selected;
            inv.setItem(g, withExtraLore(pi.getItem(invIndex), sel,
                    sel ? "\u00a7a\u2714 Selected" : "\u00a7eClick to select"));
        }
        if (h.slots.isEmpty()) {
            inv.setItem(22, plain(Material.BARRIER, "\u00a7cNo Netherite gear found",
                    "", "\u00a77Carry or wear a netherite tool,", "\u00a77weapon or armor piece."));
        }

        if (h.selected != -1) {
            ItemStack original = pi.getItem(h.selected);
            inv.setItem(SELECTED_SLOT, withExtraLore(original, false, "\u00a77Netherite"));
            inv.setItem(RESULT_SLOT, withExtraLore(makeSiftite(original), false, "\u00a7fSiftite"));
            inv.setItem(39, plain(Material.ARROW, "\u00a77\u2192"));
            inv.setItem(41, plain(Material.ARROW, "\u00a77\u2192"));
            boolean can = economy.has(p, cost);
            inv.setItem(CONFIRM_SLOT, plain(can ? Material.EMERALD_BLOCK : Material.REDSTONE_BLOCK,
                    can ? "\u00a7a\u00a7lUpgrade to Siftite" : "\u00a7c\u00a7lNot enough money",
                    "", "\u00a77Cost: \u00a76$" + money(cost),
                    "\u00a77You have: \u00a76$" + money(economy.getBalance(p)),
                    "", can ? "\u00a7eClick to upgrade" : "\u00a7cYou can't afford this yet"));
        } else {
            inv.setItem(CONFIRM_SLOT, plain(Material.GRAY_DYE, "\u00a77Pick a netherite item above",
                    "", "\u00a77Each upgrade costs \u00a76$" + money(cost) + "\u00a77."));
        }

        inv.setItem(BALANCE_SLOT, plain(Material.GOLD_INGOT,
                "\u00a76Balance: \u00a7e$" + money(economy.getBalance(p)),
                "\u00a77Upgrade cost: \u00a7e$" + money(cost) + " \u00a77per item"));
        inv.setItem(CLOSE_SLOT, plain(Material.BARRIER, "\u00a7cClose"));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof UpgradeHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;

        int slot = e.getSlot();
        if (slot < GRID_SIZE && slot < h.slots.size()) {
            h.selected = h.slots.get(slot);
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
            render(p, h, top);
        } else if (slot == CONFIRM_SLOT && h.selected != -1) {
            upgrade(p, h, top);
        } else if (slot == CLOSE_SLOT) {
            Bukkit.getScheduler().runTask(this, () -> p.closeInventory());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof UpgradeHolder) e.setCancelled(true);
    }

    // ------------------------------------------------------------------
    // The upgrade itself
    // ------------------------------------------------------------------
    private void upgrade(Player p, UpgradeHolder h, Inventory top) {
        ItemStack current = p.getInventory().getItem(h.selected);
        if (!eligible(current)) {
            p.sendMessage("\u00a7cThat item moved or changed. Pick it again.");
            h.selected = -1;
            render(p, h, top);
            return;
        }
        if (!economy.has(p, cost)) {
            p.sendMessage("\u00a7cYou need \u00a76$" + money(cost) + "\u00a7c to upgrade this item.");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }
        ItemStack result;
        try {
            result = makeSiftite(current);
        } catch (Exception ex) {
            getLogger().severe("Could not build the Siftite item: " + ex);
            p.sendMessage("\u00a7cSomething went wrong, you were not charged.");
            return;
        }
        EconomyResponse r = economy.withdrawPlayer(p, cost);
        if (!r.transactionSuccess()) {
            p.sendMessage("\u00a7cPayment failed: " + r.errorMessage);
            return;
        }
        p.getInventory().setItem(h.selected, result);
        h.selected = -1;
        p.sendMessage("\u00a7aYour gear was upgraded to \u00a7fSiftite\u00a7a for \u00a76$" + money(cost) + "\u00a7a!");
        p.playSound(p.getLocation(), Sound.BLOCK_SMITHING_TABLE_USE, 1f, 1f);
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.2f);
        render(p, h, top);
    }
}
